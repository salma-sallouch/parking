#include <gtk/gtk.h>


void
on_buttonajouter_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttannuler_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttsupprimer_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodifier_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonannulermodif_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonrechercher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonafficher_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_butajout_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_butmodif_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_butsupprim_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_butaffichres_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_butaffich_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonannuler_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonrech_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonchercher_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonchercher_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_suivantajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_pr__c__dentajouter_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_precedentajouter_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_precedentajouter_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonprecedentmodifier_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsuivantmodifier_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonprecedentsupprimer_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsuivantsupprimer_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_annulerdialog2_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_validerdialog2_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_suivantafficher_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonafficherres_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_precedentafficher_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonquitter_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonprecedentafficher_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsuivantafficheragent_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonprecedentafficheragent_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsuivantsupprimer_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_suivantsupprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonprecedentchercher_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bouttonsuivantchercher_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_bouttonsuivantchercher_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_butrech_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonverifier_clicked              (GtkButton       *button,
                                        gpointer         user_data);
