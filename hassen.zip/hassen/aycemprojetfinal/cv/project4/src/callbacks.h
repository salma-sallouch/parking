#include <gtk/gtk.h>


void
on_treeviewparking_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ajotaff_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_Chercher_Parking_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiseraff_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_affecteraff_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_suppaff_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifaff_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_annulerajoutp_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouterp_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_modifiermp_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_annulermp_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimersup_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_annulersup_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_affectag_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_annuleraffag_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewaffecteragent_row_activated (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_actualiseraffecte_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_verifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourajout_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_retmodif_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_reterrrmodif_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_rtsupprim_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_reterrrsoppr_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_menuajout_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_menumodif_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_menusupp_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_menuaffect_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_annulertrvp_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercherprk_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_mntrvp_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_retprnex_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercherchertrv_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_calculer_moyennes_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_accederlogin_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_retauloginbutton1_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_retajouttt_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_retloginincorr_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ajouter_button1__clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_button2_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_button3_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_button4_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_rechercher_button5_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_carte_radiobutton1_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_carte_radiobutton2_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_matin_radiobutton3_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_apresmidi_radiobutton10_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton003_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ajouter_button6_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_annuler_button7_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_acceuiservicebutton2_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_verifieridservice__clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_cartemod_radiobutton5_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_especesmod_radiobutton6_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_matinmod_radiobutton7_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_apresmidi_radiobutton8_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton004_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_modifier_button8_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_anuller_button9_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_modfierservicebutton3_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_anuller_button11_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_button10_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_accssbutton15_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewaffecter_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_affecter_button12_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_annuleraff_button13_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_accaff_button19_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonseconnecteradmn_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonarriereseconnectadmn_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonoffrehz_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonprecedentajouthz_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonannulerhz_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonconfirmhz_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsuivajouthz_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonannulereservationhz_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsuivantmodifierhz_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonconfirmerreservationhz_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonprecedentmodifierhz_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonaffichage_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonchercher_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonannuler_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsupprimer_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaffichement_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonprecedaffich_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonhome_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttontarif_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonconfabonnmt_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonannulerabonnement_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonprecedoffre_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajouter_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsupp_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodifi_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaffich_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonprecedoption_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttoncreeruncompteclient_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonarriereseconnectclient_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonseconnecterclient_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonloginclient_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button24_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonloginadmn_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonadminis_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonclient_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongererreservation_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_geravi_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonprecedespclient_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonpreceespadmns_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttoncherche1_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
