#include <gtk/gtk.h>


void on_Ajouter_clicked (GtkWidget *objet_graphique, gpointer user_data);
void on_Suivant_clicked (GtkButton *button, gpointer user_data);


void
on_button_afficher_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_precedent_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_suivant_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_chercher_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_suivant1_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_cherche_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_precedent2_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_suivant3_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_afficher1_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_trier_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_affichagetous_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_precedent555_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_suivant555_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_precedent666_clicked         (GtkButton       *button,
                                        gpointer         user_data);
